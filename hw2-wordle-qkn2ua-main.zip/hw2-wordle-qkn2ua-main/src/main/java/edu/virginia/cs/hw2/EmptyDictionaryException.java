package edu.virginia.cs.hw2;

public class EmptyDictionaryException extends IllegalStateException {
    public EmptyDictionaryException(String message) {
        super(message);
    }
}
