package edu.virginia.cs.hw2;

public class IllegalWordException extends IllegalArgumentException {
    public IllegalWordException(String message) {
        super(message);
    }
}
